<div class="entry-meta clear">

	<span class="entry-author"><?php the_author_posts_link(); ?> &#8212; </span> 
	<span class="entry-date"><?php echo get_the_date(); ?></span>

	<span class='entry-comment'><?php comments_popup_link( 'add comment', '1 comment', '% comments', 'comments-link', 'comments off'); ?></span>
	
</div><!-- .entry-meta -->